// 1) Assign Animals
console.log("***** Favourite Animal *****");
let favouriteAnimal = "Wolf";
console.log("My Favourite Animal is: " + favouriteAnimal);

// 2) The Sum of A and B
console.log("***** The Sum Of A and B *****");
let a = 25;
let b = 352;
console.log(a + b + " Is The Sum Of A and B");

// 3) Age Variable
console.log("***** Age Variable *****");
let age = 29;
console.log("I Am " + age + " Years old");

// 4) Country Variable
console.log("***** Country Variable *****");
let country = "France";
country = "Spain";
console.log("My Favourite Country Is: " + country);

// 5) Declaring PI Value of 3.14
console.log("***** Declaring PI Value of 3.14 *****");
let pi = 3.14;
console.log("PI is: " + pi);

// 6) Favoutrie Color
console.log("***** Favoutrie Color *****");
let favouriteColor = "Black";
console.log("My Favourite Color Is: " + favouriteColor);

// 7) Variable X and Variable Y
console.log("***** Variable X and Variable Y *****");
let x = 5;
let y = 10;
let sum = x + y;
console.log(sum + " Is The Sum Of X and Y");

// 7) Variable isSunny to true
console.log("***** Variable isSunny to true *****");
let isSunny = true;
console.log(isSunny + " It Is Sunny Day");